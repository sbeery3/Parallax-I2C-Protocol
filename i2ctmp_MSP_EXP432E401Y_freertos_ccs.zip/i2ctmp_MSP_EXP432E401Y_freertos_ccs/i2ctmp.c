/*****************************************************************************
*
* Copyright (C) 2013 - 2017 Texas Instruments Incorporated - http://www.ti.com/
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
*   notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
*   notice, this list of conditions and the following disclaimer in the
*   documentation and/or other materials provided with the
*   distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
*   its contributors may be used to endorse or promote products derived
*   from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
* A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
* OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
* THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
******************************************************************************
*
* MSP432 empty main.c template
*
******************************************************************************/

/*
 *    ======== i2cmasterexample1.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
//#include <unistd.h>

/* Driver Header files */
#include <ti/drivers/I2C.h>
#include <C:\ti\simplelink_msp432e4_sdk_4_20_00_12\source\ti\drivers\I2C.h>


//#include <ti/display/Display.h>

/* Driver configuration */
#include "ti_drivers_config.h"

//static Display_Handle display;

/* Buffers used in this code example */
uint8_t txBuffer[10];
uint8_t rxBuffer[10];
uint8_t mirrorRegister[26] = "x Hello this is master";

/*User created constants */


/*

uint16_t C1; //Pressure Sensitivity
uint16_t C2; //Pressure Offset
uint16_t C3; //Pressure Sense Temp Coeff
uint16_t C4; //Pressure Offset Temp Coeff
uint16_t C5; //Reference Temperature
uint16_t C6; //Temperature Temp Coeff
*/

uint32_t calibration_data[6]; //Calibration data array

uint32_t D1_pressure; //Digital Pressure Value
uint32_t D2_temp;     //Digital Temperature Value


//#include "msp.h"

//Change yo i2ctransaction to trans
//Read buffer good stuff
//Change read/write counts based on size of byte
//Store write buffers in array
//Debug stuff to confirm you're not dumb ;)

void i2c_altimeter_thread(void)
{
    printf("yeahhh");

    // Initializes I2C handles
    I2C_Handle      i2c;
    I2C_Params      i2cParams;
    I2C_Transaction i2cTransaction;

    // Initializes PROM transfer addresses used
    uint8_t prom_addresses[3] = {0xA6, 0x48, 0x58};

    //Constructs I2C
    I2C_init();
    I2C_Params_init(&i2cParams);

    // Sets Bit Rate
    i2cParams.bitRate = I2C_100kHz;

    // Opens I2C
    i2c = I2C_open(0, &i2cParams);

    //If I2C is not responding, enter infinite while loop
    if (i2c == NULL) {
        printf("Error initializing!");
        while (1) {}
    }


    //Initialize slave address
    i2cTransaction.slaveAddress = 0b111011; //111011CSB???

    //Sets up PROM read mode
    i2cTransaction.writeBuf = &prom_addresses[0];
    i2cTransaction.writeCount = 1; //Write to Slave to setup PROM
    i2cTransaction.readCount = 0;
    I2C_transfer(i2c, &i2cTransaction);



    //Reads Calibration Data
    i2cTransaction.writeCount = 0;
    i2cTransaction.readCount = 1; //Read from Slave

    int i;
    //Stores calibration data in array
    for (i=0;i<6;i++){
        I2C_transfer(i2c, &i2cTransaction);
        // Stores calibration data from init prom read
        calibration_data[i] = (uint32_t)&i2cTransaction.readBuf;
    }


    //FIGURE OUT HOW TO WHILE !I2C_close()

    while (1) {

        //Assuming OSR=4096

        /*
        * Reading Pressure D1
        */
        //Command to initiate pressure conversion
        i2cTransaction.writeBuf = &prom_addresses[1];
        i2cTransaction.writeCount = 1; //Write to Slave to initiate pressure conversion
        i2cTransaction.readCount = 0;
        I2C_transfer(i2c, &i2cTransaction);

        //I2C ADC Read Sequence (STILL NOT READING)
        i2cTransaction.writeBuf = 0x00;
        I2C_transfer(i2c, &i2cTransaction);

        //Read Pressure
        i2cTransaction.writeCount = 0;
        i2cTransaction.readCount = 1;
        D1_pressure = I2C_transfer(i2c, &i2cTransaction);


        /*
        * Reading Temperature D2
        */

        //Command to initiate temperature conversion
        i2cTransaction.writeBuf = &prom_addresses[2];
        i2cTransaction.writeCount = 1; //Write to Slave to initiate temperature conversion
        i2cTransaction.readCount = 0;
        I2C_transfer(i2c, &i2cTransaction);

        //I2C ADC Read Sequence (STILL NOT READING)
        i2cTransaction.writeBuf = 0x00;
        I2C_transfer(i2c, &i2cTransaction);

        //Read Temperature
        i2cTransaction.writeCount = 0;
        i2cTransaction.readCount = 1;
        D2_temp = I2C_transfer(i2c, &i2cTransaction);



        /*
        * Calculate Temperature
        */

        uint32_t dT = D2_temp - calibration_data[4] * 256;

        uint32_t TEMP = 2000 + dT * calibration_data[5] / 8388608;


        /*
        * Calculate Pressure
        */

        uint64_t OFF = calibration_data[1] * (131072) + (calibration_data[3] * dT) / (64);
        uint64_t SENS = calibration_data[0] * (65536) + (calibration_data[2] * dT) / (128);

        uint32_t P = (D1_pressure * SENS / (2097152 - OFF)) / (32768);


        /*
        * Output values
        */
        printf("Temperature: %d\n", TEMP);
        printf("Pressure: %d\n", P);
    }

    I2C_close(i2c);

}
